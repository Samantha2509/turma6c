class Conversoes{

public static void main(String args[]){
// Conversoes implicitas => o Java faz pra você (dado menor em um espaço maior)
// byte < short < int < long
byte numeroPequeno = 5; //nesta linha estou criando uma variavel 
long numeroGrande = numeroPequeno;
System.out.println(numeroGrande);
// Conversão explicita (Cast) => 
// Você tem que mostrar quem manda. (dado maior em um espaço menor)
double numeroReal=1.57;
int numeroMedio = (int) numeroReal; 
System.out.println(numeroMedio);
// Conversão entre dados incompatíveis => Parse
// Classes Wrappers => são classes que apoiam os tipos primitivos
// int => Integer
// double => Double
// float => Float (...)
String numero = "7";
numeroMedio = Integer.parseInt(numero);
numeroReal = Double.parseDouble(numero);
numeroPequeno = Byte.parseByte(numero);
System.out.println("Após o parse: ");
System.out.println("Byte: " + numeroPequeno);
System.out.println("Integer: " + numeroMedio);
System.out.println("Double: " + numeroReal);

}

}