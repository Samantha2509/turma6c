import java.util.Scanner;
class Lista1Exercicio3{

public static void main(String args[]){

Scanner teclado = new Scanner(System.in);

System.out.println("Digite o capital:");
float capital = teclado.nextFloat();

System.out.println("Digite a taxa mensal:");
double taxa = teclado.nextDouble();

System.out.println("Digite o período(meses):");
int periodo = teclado.nextInt();

float montante = capital * (float) Math.pow(1 + taxa/100, periodo);
System.out.println("Montante de: "  + montante);
// Outra forma de printar o dado
System.out.printf("O capital inicial foi de: %.2f e o montante de: %.3f", capital, montante);



}

}