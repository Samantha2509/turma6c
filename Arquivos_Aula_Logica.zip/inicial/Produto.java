import java.util.Scanner;

class Produto{

public static void main(String args[]){
Scanner teclado = new Scanner(System.in);

System.out.println("Digite o nome do produto");
String produto = teclado.next() + teclado.nextLine();

System.out.println("Digite a qtde do produto");
int qtde = teclado.nextInt();

System.out.println("Digite o valor unitário do produto");
float valorUnitario = teclado.nextFloat();

//System.out.println("Valor Total: " + (qtde*valorUnitario));
float total = qtde * valorUnitario;
System.out.println("Valor Total: " + total);

System.out.println("Valor com Desconto: " + (total * 0.9));
System.out.println("Valor com Acrescimo: " + (total * 1.1));




}

}







