import javax.swing.JOptionPane;

class DecisaoSimples{

public static void main(String args[]){

String nome = JOptionPane.showInputDialog("Nome: ").toUpperCase();
float nota1 = Float.parseFloat(JOptionPane.showInputDialog("Digite a nota 1:"));
float nota2 = Float.parseFloat(JOptionPane.showInputDialog("Digite a nota 2:"));
float media = (nota1+nota2)/2;

// media maior ou igual a 5 ele está aprovado
// media < 3 => Reprovado
// media estiver entre 4,9 e 3 => Exame


if (media>=5){
	System.out.println("Parabéns " + nome + ", você foi aprovado(a)!");
}

if (media<3){
	System.out.println(nome + " infelizmente você foi reprovado(a)!");
}

// && => and (duas condições devem ser verdadeiras)
// || => or (uma das condições tem que ser verdadeiras)
// ! => não (negação. Exemplo != ) 

if (media<5 && media>=3){
	Sytem.out.println(nome + " você terah mais uma chance.");
} 

System.out.println("Até logo!");

}
}