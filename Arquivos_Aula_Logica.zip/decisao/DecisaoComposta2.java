import javax.swing.JOptionPane;

class DecisaoComposta2{

public static void main(String args[]){
String nome = JOptionPane.showInputDialog("Nome").toUpperCase();
int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade"));

if (idade>=18 && idade<=70){
	System.out.println(nome + "você é obrigado a votar!");
}else if (idade < 16) {
	System.out.println(nome + " você está proibido de votar");
}else{
	System.out.println(nome + " o seu voto é facultativo!");
}

}
}