import javax.swing.JOptionPane;

class Lista2Exercicio1{

public static void main(String args[]){

String nome = JOptionPane.showInputDialog("Digite o nome").toUpperCase();
int diarias = Integer.parseInt(JOptionPane.showInputDialog("Digite as qtde de diárias"));
float taxa=0;
if (diarias>15){
	taxa = (float) 5.5;
}else if(diarias==15){
	taxa=6;
}else{
	taxa=8;
}
float total = diarias * (80 + taxa);
System.out.println("Sr(a) " + nome + "\nA sua conta eh de: " + total);


}

}