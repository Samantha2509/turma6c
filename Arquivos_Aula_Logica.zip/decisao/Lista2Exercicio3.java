import javax.swing.JOptionPane;
class Lista2Exercicio3{

public static void main(String args[]){

int numero1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro numero"));
int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo numero"));
String operador = JOptionPane.showInputDialog("Digite: \n<+> para Somar\n<-> para Subtrair\n<*> para Multiplicar\n</> para Dividir");

if (operador.equals("+")){
	System.out.println("Soma: " + (numero1+numero2));
}else if (operador.equals("-")){
	System.out.println("Subtracao: " + (numero1-numero2));
}else if (operador.equals("*")){
	System.out.println("Multiplicacao: " + (numero1*numero2));
}else if (operador.equals("/")){
	if (numero2==0){
		System.out.println("Não pode dividir por zero");
	}else{
		System.out.println("Dividir: " + (numero1/numero2));
	}	
}else{
	System.out.println("Opção inválida");
}

}

}