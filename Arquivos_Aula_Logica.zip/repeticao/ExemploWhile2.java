import javax.swing.JOptionPane;

class ExemploWhile2{

public static void main(String args[]){

String nome = JOptionPane.showInputDialog("Digite o produto").toUpperCase();
float valor = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor"));

while (nome.length()<6){
	nome = JOptionPane.showInputDialog("Digite o produto").toUpperCase();
}

while (valor<11){
	valor = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor"));
}

JOptionPane.showMessageDialog(null, "Produto: " + nome + "\nValor: " + valor);

}

}