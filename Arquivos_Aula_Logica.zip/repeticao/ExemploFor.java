import java.util.Scanner;

class ExemploFor{

public static void main(String args[]){

//Laço de Repetição For (indicado para não interação com o usuário)
//Formado por três partes:
//1º - Variável que irá contar e por onde ela vai começar
//2º - Condição 
//3º - Incremento
Scanner teclado = new Scanner(System.in);
System.out.println("Digite a tabuada desejada");
int tabuada = teclado.nextInt();
for (int contador=1;contador<11;contador++){
	System.out.println(tabuada + " x " + contador + " = " + (tabuada*contador));
}


}
}