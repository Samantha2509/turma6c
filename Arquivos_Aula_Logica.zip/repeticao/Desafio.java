import javax.swing.JOptionPane;

class Desafio{

public static void main(String args[]){

int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
int chute =0;
int contar=0;
do{
	chute = Integer.parseInt(JOptionPane.showInputDialog("Advinhe o número"));
	contar=contar+1;
	if (chute>numero){
		JOptionPane.showMessageDialog(null, "Você chutou alto");		
	}else if (chute<numero){
		JOptionPane.showMessageDialog(null, "Você chutou baixo");
	}
}while(numero!=chute);

JOptionPane.showMessageDialog(null, "Parabéns você acertou com " +  contar + " tentativas!");

// Jogo de advinhação:
// Sua aplicação pede um número para o Jogador 1
// Sua aplicação pede o segundo número para o Jogador 2, que deve descobrir qual foi o 
// número digitado pelo Jogador1.
}
}