import javax.swing.JOptionPane;

class Slide77Exercicio3{

public static void main(String args[]){
String formacao="";
int contadorPos=0;
int contadorSuperior=0;
int contadorMedio=0;
do{
	formacao = JOptionPane.showInputDialog("Digite sua formação:").toUpperCase();
	if (formacao.equals("POS")){
		contadorPos=contadorPos+1;
		//contadorPos++;
	}else if (formacao.equals("MEDIO")){
		contadorMedio++;
	}else if (formacao.equals("SUPERIOR")){
		contadorSuperior++;
	}
}while(formacao.equals("POS") || formacao.equals("SUPERIOR") || formacao.equals("MEDIO");

if (contadorPos>contadorMedio && contadorPos>contadorSuperior){
	JOptionPane.showMessageDialog("O mais selecionado foi Pós com " + contadorPos + " pessoas");
}else if (contadorMedio>contadorSuperior){
	JOptionPane.showMessageDialog("O mais selecionado foi Médio com " + contadorMedio + " pessoas");
}else{
	JOptionPane.showMessageDialog("O mais selecionado foi Superior com " + contadorSuperior + " pessoas");
}
}

}