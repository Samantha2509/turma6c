import java.util.Scanner;

class Lista1Exercicio5{

public static void main(String args[]){
Scanner teclado = new Scanner(System.in);
System.out.println("Digite o ano do seu nascimento: ");
int anoNascimento = teclado.nextInt();

System.out.println("Digite o ano atual: ");
int anoAtual = teclado.nextInt();

int idade = anoAtual - anoNascimento;
System.out.println("Sua idade eh:" + idade);
int idade2050 = 2050-anoNascimento;
System.out.println("Em 2050 sua idade serah:" + idade2050);
//OU
System.out.println("Sua idade eh:" + (anoAtual-anoNascimento));
System.out.println("Sua idade em 2050 serah:" + (2050-anoNascimento));

}

}