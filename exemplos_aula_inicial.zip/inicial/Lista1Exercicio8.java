import java.util.Scanner;

class Lista1Exercicio8 {

public static void main(String args[]){
Scanner teclado = new Scanner(System.in);

System.out.println("Digite o valor a ser sacado: ");
int valor = teclado.nextInt();

int nota100 = valor / 100;
System.out.println("Qtde de notas de 100: " + nota100);
valor = valor % 100; 
System.out.println("Restaram: " + valor);

int nota50 = valor / 50;
System.out.println("Qtde de notas de 50: " + nota50);
valor = valor % 50; 
System.out.println("Restaram: " + valor);

}

}