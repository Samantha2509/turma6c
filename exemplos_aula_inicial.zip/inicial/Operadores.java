import java.util.Scanner;
class Operadores{
public static void main(String args[]){
Scanner teclado = new Scanner(System.in);

System.out.println("Digite o primeiro número");
int numero1 = teclado.nextInt();

System.out.println("Digite o segundo número");
int numero2 = teclado.nextInt();

System.out.println("Divisao: " + (numero1/numero2));
System.out.println("Resto: " + (numero1%numero2));
System.out.println("Numero 1 é par?: " + (numero1%2==0));
numero1++;
// numero1 = numero1 + 1;
System.out.println("Incremento de 1: " + numero1);
System.out.println("Incremento de 2: " + (numero1+=2)); //numero1=numero1+2;

}
}