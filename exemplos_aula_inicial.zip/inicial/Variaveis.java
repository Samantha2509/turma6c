class Variaveis{

public static void main(String args[]){

String nome = "Humberto";
String sobrenome = "Delgado de Sousa";
int idade = 45;
float altura = (float) 1.74;
double peso = 95;
double imc = peso / (altura * altura);

System.out.println("Nome......: " + nome);
System.out.println("Sobrenome.: " + sobrenome);
System.out.println("Idade.....: " + idade);
System.out.println("Altura....: " + altura);
System.out.println("Peso......: " + peso);
System.out.println("IMC.......: " + imc);

}

}