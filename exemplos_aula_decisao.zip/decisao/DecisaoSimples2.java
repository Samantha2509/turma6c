import javax.swing.JOptionPane;

class DecisaoSimples2{

public static void main(String args[]){
String nome = JOptionPane.showInputDialog("Nome").toUpperCase();
int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade"));

if (idade>=18 && idade<=70){
	System.out.println(nome + "você é obrigado a votar!");
}

if (idade < 16) {
	System.out.println(nome + " você está proibido de votar");
}

if (idade==16 || idade==17 || idade>70){
	System.out.println(nome + " o seu voto é facultativo!");
}

}
}