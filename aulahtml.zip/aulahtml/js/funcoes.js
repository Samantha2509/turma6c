function exibir(){
    window.alert("Hello World");
}

function verificar(){
    var numero = window.prompt("Digite um número");
    var resultado = parseInt(numero) % 2;
    if (resultado==0){
        window.alert("Número é par!");
    }else{
        window.alert("Número é impar!");
    }
}