package br.com.projetofinal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetofinal.dao.ArtistaDAO;
import br.com.projetofinal.model.Artista;

@RestController
@CrossOrigin("*")
public class ArtistaController {
	
	@Autowired
	private ArtistaDAO dao;
	
	@GetMapping("/artistas")
	public ResponseEntity<List<Artista>> retornarArtistas(){
		ArrayList<Artista> resultado = (ArrayList<Artista>) dao.findAll();
		if (resultado.size()==0) {
			return ResponseEntity.status(403).build();
		}
		return ResponseEntity.ok(resultado);
	}
	
	@GetMapping("/artista/{id}")
	public ResponseEntity<Artista> retornarArtista(@PathVariable int id){
		Artista resposta = dao.findById(id).orElse(null);
		if (resposta==null) {
			return ResponseEntity.status(403).build();
		}
		return ResponseEntity.ok(resposta);
	}
	
	@GetMapping("/nacionalidade/{nac}")
	public ResponseEntity<List<Artista>> pesquisarNac(@PathVariable String nac){
		ArrayList<Artista> resposta = (ArrayList<Artista>) dao.findByNacionalidade(nac);
		if (resposta.size()==0) {
			return ResponseEntity.status(404).build();
		}
		return ResponseEntity.ok(resposta);
	}
	
	@GetMapping("/teste/{nac}")
	public ResponseEntity<List<Artista>> pesquisaTeste(@PathVariable String nac){
		ArrayList<Artista> lista = (ArrayList<Artista>) dao.findByNacionalidade(nac);
		List<Artista> resultado= new ArrayList<Artista>();
		for (Artista a : lista) {
			char ultimo = 
		a.getNomeArtistico().toUpperCase().charAt(a.getNomeArtistico().length()-1);
			
			if (ultimo=='A') {
				resultado.add(a);
			}
		}
		if (resultado.size()==0) {
			return ResponseEntity.status(404).build();			
		}
		return ResponseEntity.ok(resultado);
	}
	
	@PostMapping("/novoartista")
	public ResponseEntity<Artista> gravar(@RequestBody Artista artista){
		try {
			if (artista.getNomeArtistico().length()>30) {
				return ResponseEntity.status(403).build();
			}
			dao.save(artista);
			return ResponseEntity.ok(artista);
		}catch(Exception e) {
			return ResponseEntity.status(403).build();	
		}
	}
	
	@PostMapping("/nacionalidadepost/")
	public ResponseEntity<List<Artista>> pesquisarNacPost
									(@RequestBody Artista artista){
		ArrayList<Artista> resposta = 	(ArrayList<Artista>) 
				dao.findByNacionalidade(artista.getNacionalidade());
		
		if (resposta.size()==0) {
			return ResponseEntity.status(404).build();
		}
		return ResponseEntity.ok(resposta);
	}
}








