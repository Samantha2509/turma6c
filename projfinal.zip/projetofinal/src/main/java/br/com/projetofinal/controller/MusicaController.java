package br.com.projetofinal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetofinal.dao.MusicaDAO;
import br.com.projetofinal.model.Musica;

@RestController
@CrossOrigin("*")
public class MusicaController {

	@Autowired
	private MusicaDAO mdao;
	
	@PostMapping("/novamusica")
	public ResponseEntity<Musica> nova(@RequestBody Musica musica){
		try {
			mdao.save(musica);
			return ResponseEntity.ok(musica);
		}catch(Exception e) {
			return ResponseEntity.status(403).build();
		}
	}
	
}








