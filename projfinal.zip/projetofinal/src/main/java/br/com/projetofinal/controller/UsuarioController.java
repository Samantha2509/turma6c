package br.com.projetofinal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetofinal.dao.UsuarioDAO;
import br.com.projetofinal.model.Usuario;

@RestController // para que a classe responda aos protocolos HTTP
@CrossOrigin("*")
public class UsuarioController {
	 
	@Autowired // o controle da instancia fica para o JPA
	private UsuarioDAO udao;
	
	
	@GetMapping("/usuarios")
	public ResponseEntity<List<Usuario>> retornarUsuarios(){
		ArrayList<Usuario> lista = (ArrayList<Usuario>) udao.findAll();
		if (lista.size()==0) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(lista);
	}
	
	@GetMapping("/usuario/{id}")
	public ResponseEntity<Usuario> pesquisarPorCodigo(@PathVariable int id){
		Usuario objeto = udao.findById(id).orElse(null);
		if (objeto==null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(objeto);
	}
	
	@PostMapping("/login")
	public ResponseEntity<Usuario> logar(@RequestBody Usuario usuario){
		Usuario objeto = udao.findByEmailAndSenha
				(usuario.getEmail(), usuario.getSenha());
		if (objeto == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(objeto);
	}

} // fechar a classe






