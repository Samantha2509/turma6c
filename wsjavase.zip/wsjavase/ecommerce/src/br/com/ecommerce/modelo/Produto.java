package br.com.ecommerce.modelo;

/*
 * Padr�o => DTO (TO ou Beans) =>  Data Transfer Object
 * - Todo atributo deve ser private
 * - Todo atributo deve possuir um m�todo GET (output) e SET (input)
 * - Deve existir um contrutor vazio e um outro construtor para preencher o objeto (no m�nimo) 
 */
public class Produto {

	private int id;
	private String descricao;
	private int qtde;
	private float valorCompra;
	private float valorVenda;

	public Produto() {
		super();
	}

	public Produto(int id, String descricao, int qtde, float valorCompra, float valorVenda) {
		super();
		this.id = id;
		this.descricao = descricao;
		this.qtde = qtde;
		this.valorCompra = valorCompra;
		this.valorVenda = valorVenda;
	}

	public double getValorVista(float x) {
		return valorVenda - valorVenda * (x / 100);
	}
	
	public String getDescricaoSimples() {
		if (descricao.indexOf(" ")==-1) { // -1 significa q ele n�o encontrou o espa�o
			return descricao;
		}else {
			return descricao.substring(0, descricao.indexOf(" "));
		}
	}
	
	public String avaliarEstoque() {
		if (qtde>20) {
			return "Estoque cheio";
		}else if(qtde<10) {
			return "Estoque baixo";
		}else {
			return "Estoque m�dio";
		}
	}
	
	public void setAjuste(float porcentagem) {
		valorCompra = valorCompra + valorCompra * (porcentagem/100);
		valorVenda = valorVenda + valorVenda * (porcentagem/100);
	}
	
	
	public double getValorVista() {
		return valorVenda * 0.9;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String x) {
		this.descricao = x.toUpperCase();
	}

	public int getQtde() {
		return qtde;
	}

	public void setQtde(int qtde) {
		this.qtde = qtde;
	}

	public float getValorCompra() {
		return valorCompra;
	}

	public void setValorCompra(float valorCompra) {
		this.valorCompra = valorCompra;
	}

	public float getValorVenda() {
		return valorVenda;
	}

	public void setValorVenda(float valorVenda) {
		this.valorVenda = valorVenda;
	}

	public float getSubTotalVenda() {
		return  qtde * valorVenda;
	}
	
	public String getAll() {
		return 
				"C�digo.......: " + id + "\n" +
				"Descri��o....: " + descricao + "\n" + 
				"Qtde.........: " + qtde + "\n" + 
				"Valor Compra.: " + valorCompra + "\n" + 
				"Valor Venda..: " + valorVenda;
	}
	
	public void setAll(int i, String d, int q, float vc, float vv) {
		id = i;
		descricao=d;
		qtde = q;
		valorCompra=vc;
		valorVenda =vv;
	}
	
	
}
