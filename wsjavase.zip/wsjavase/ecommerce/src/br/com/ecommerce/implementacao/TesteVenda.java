package br.com.ecommerce.implementacao;

import javax.swing.JOptionPane;

import br.com.ecommerce.modelo.Cliente;
import br.com.ecommerce.modelo.Endereco;
import br.com.ecommerce.modelo.Produto;
import br.com.ecommerce.modelo.Venda;
import br.com.ecommerce.tela.Magica;

public class TesteVenda {
	
	public static void main(String[] args) {
		Venda venda = new Venda(
				Magica.i("Numero NF"),
				new Cliente(
						Magica.t("CPF"),
						Magica.t("Nome"),
						Magica.t("Fone"),
						Magica.f("Limite"),
						new Endereco(
								Magica.t("Logradouro"),
								JOptionPane.showInputDialog("Numero"),
								JOptionPane.showInputDialog("Complemento"),
								JOptionPane.showInputDialog("Bairro"),
								JOptionPane.showInputDialog("Cidade"),
								JOptionPane.showInputDialog("UF"),
								JOptionPane.showInputDialog("CEP")
								)
						),
				new Produto(
						Integer.parseInt(JOptionPane.showInputDialog("C�digo")),
						JOptionPane.showInputDialog("Descricao"),
						Integer.parseInt(JOptionPane.showInputDialog("Qtde")),
						Float.parseFloat(JOptionPane.showInputDialog("Vlr Compra")),
						Float.parseFloat(JOptionPane.showInputDialog("Vlr Venda"))
						),
				Float.parseFloat(JOptionPane.showInputDialog("Total:")),
				JOptionPane.showInputDialog("Data")
				);
		System.out.println(venda.getAll());
	}

}
