package br.com.ecommerce.implementacao;

import javax.swing.JOptionPane;

import br.com.ecommerce.modelo.Produto;

public class TesteProduto {


	public static void main(String[] args) {
		//Criando o objeto = um buraco negro na mem�ria
		//Produto produto;
		
		//Instanciando o objeto = o objeto possui suas reparti��es 
		Produto produto = new Produto();
		
		produto.setDescricao(JOptionPane.showInputDialog("Descricao"));
		produto.setId(Integer.parseInt(JOptionPane.showInputDialog("ID")));
		produto.setQtde(Integer.parseInt(JOptionPane.showInputDialog("Qtde")));
		produto.setValorCompra(Float.parseFloat(JOptionPane.showInputDialog("Valor Compra")));

		produto.setValorVenda(Float.parseFloat(JOptionPane.showInputDialog("Valor Venda")));
				
		System.out.println(produto.getAll());
		
		System.out.println("=========================================");
		System.out.println("Subtotal Venda: " + produto.getSubTotalVenda());
		System.out.println("Valor com 10%: " + produto.getValorVista());
		
		Float porcentagem = Float.parseFloat(JOptionPane.showInputDialog("Porcentagem"));
		produto.setAjuste(porcentagem);
		System.out.println("Ajustado Compra: " + produto.getValorCompra());
		System.out.println("Ajustado Venda: " + produto.getValorVenda());
		System.out.println(produto.avaliarEstoque());
		System.out.println("Descri��o simplificada: " + produto.getDescricaoSimples());
		System.out.println("Valor Venda com Desconto: " + produto.getValorVista(porcentagem));

	}

}
