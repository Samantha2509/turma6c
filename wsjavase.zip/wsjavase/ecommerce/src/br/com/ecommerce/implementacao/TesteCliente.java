package br.com.ecommerce.implementacao;

import javax.swing.JOptionPane;

import br.com.ecommerce.modelo.Cliente;
import br.com.ecommerce.modelo.Endereco;

public class TesteCliente {

	public static void main(String[] args) {

		Cliente objeto = new Cliente(
				JOptionPane.showInputDialog("CPF"),
				JOptionPane.showInputDialog("Nome").toUpperCase(),
				JOptionPane.showInputDialog("Fone"),
				Float.parseFloat(JOptionPane.showInputDialog("Limite")),
				new Endereco(
						JOptionPane.showInputDialog("Logradouro"),
						JOptionPane.showInputDialog("N�mero"),
						JOptionPane.showInputDialog("Complemento"),
						JOptionPane.showInputDialog("Bairro"),
						JOptionPane.showInputDialog("Cidade"),
						JOptionPane.showInputDialog("UF"),
						JOptionPane.showInputDialog("CEP")
						)
				);
		System.out.println(objeto.getAll());
		
	}

}
