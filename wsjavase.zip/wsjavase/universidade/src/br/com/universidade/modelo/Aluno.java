package br.com.universidade.modelo;

public class Aluno {

	private String nome;
	private String email;
	private int rm;
	// Sintaxe para cria��o de um m�todo
	// <modificador> <retorno> <nomeDoMetodo> ( <tipoParametro> <nomeParametro>, ... ) {}
	
	public String exibirTudo() {
		return 
				"Nome..: " + nome + "\n" +
				"Email.: " + email + "\n" + 
				"Rm....: " + rm;
	}
	
	public void preencherTudo(String pNome, String pEmail, int pRm) {
		nome=pNome;
		email=pEmail;
		rm=pRm;
	}
	
	//M�todo de output
	public String exibirEmail() {
		return email;
	}
	
	public int exibirRm() {
		return rm;
	}
	
	public String exibirNome() {
		return nome;
	}
	
	// M�todo de input
	public void preencherNome(String pNome) {
		nome = pNome;
	}
	public void preencherRm(int pRm) {
		rm=pRm;
	}
	
	public void preencherEmail(String pEmail) {
		email=pEmail;
	}
	
}
