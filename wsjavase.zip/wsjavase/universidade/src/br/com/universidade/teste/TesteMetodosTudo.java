package br.com.universidade.teste;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.Aluno;

public class TesteMetodosTudo {

	public static void main(String[] args) {
		Aluno aluno = new Aluno();
		aluno.preencherTudo(
				JOptionPane.showInputDialog("Digite o nome"), 
				JOptionPane.showInputDialog("Digite o email"), 
				Integer.parseInt(JOptionPane.showInputDialog("RM"))
				);
		System.out.println(aluno.exibirTudo());
		
	}

}
