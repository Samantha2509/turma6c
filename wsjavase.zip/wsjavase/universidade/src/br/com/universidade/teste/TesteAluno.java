package br.com.universidade.teste;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.Aluno;

public class TesteAluno {

	public static void main(String[] args) {
		//Cria o objeto
		//Aluno objeto2;
		// objeto2.nome = "xpto";
		
		//Instancia o objeto
		Aluno objeto = new Aluno();
		objeto.preencherNome(JOptionPane.showInputDialog("Digite o nome: "));
		objeto.preencherEmail("humberto@fiap.com.br");
		objeto.preencherRm(789777);
		System.out.println("Nome..: " + objeto.exibirNome());
		System.out.println("Email.: " + objeto.exibirEmail());
		System.out.println("RM....: " + objeto.exibirRm());
	}

}
